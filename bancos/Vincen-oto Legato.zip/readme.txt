
�� ���̉���/�L�����N�^�[��R18�R���e���c�Ɏg�p���邱�Ƃ͋֎~����Ă��܂��B�@�y�[�W�����̗��p�K������ǂ݂��������B

�� Use of this voicebank/character in R18 content is prohibited. Please read the terms of use near the bottom of the page.


----------------------------------------------


Vincen-oto -Legato-�@|�@���B���Z������ -Legato-
         
       �y Japanese CVVC �z 


----------------------------------------------


Voice Provider:�@Colle (snowsorry)

Author/Manager:�@snowsorry

Oto Configuration:�@snowsorry

�\

Recommended Resamplers:�@TIPS, moresampler


----------------------------------------------


       �y PITCHES �z


Low �� High:  E3, G3, B3, F4, A4, D5

�\


       �y END NOTES �z


Rest:�@�@[a R]  

Exhale:�@�@[a hh]  

Glottal stop:�@�@[a q] / [���E] 

�\


       �y EXTRAS �z


Breath (inhale):   [br]  
(5 in total: br, br2, br3, br4, etc.)

�\


Vowels:

[- V]�@=�@The "u" in "but" 

[- U]�@=�@The "ou" in "could" 

[- @]�@=�@The "a" in "hat"

[- 3]�@=�@The "ir" in "girl"*
*Sometimes mispronounced as "air"


Consonants:

[tha]�@=�@The "th" in "thank"

[dha]�@=�@The "th" in "that"

[zha]�@=�@The "s" in "treasure"

[ra] / [a r2] �@=�@The "r" in "rock"

[�K] / [nga]�@=�@The "ng" in "sing"



----------------------------------------------


       �y VOICEBANK TERMS OF USE �z


FOR MORE DETAILS, READ HERE:
snowsorry-utau.carrd.co/#terms-of-use



�\�\�t CONTENT �s�\�\


�yR18 expression�z:�@FORBIDDEN.
- Content must comply with the "Application" guidelines.


�yViolent expression�z:�@Allowed.
- Do not use to depict or encourage real-life violence or crimes.


�yReligious expression�z:�@Allowed. 
- Do not use with the intent of proselytization nor as promotion for real-life actions.


�yFan art/Doujin�z:�@Allowed.
- Content must comply with the "Application" guidelines.


�yOriginal songs/works�z:�@Non-commercial use is allowed.
- Voicebank and author must be credited.


�yCommercial use�z:�@Permission required.
- Asset or data use for NFTs is prohibited.



�\�\�t APPLICATION �s�\�\


- Do not use my voicebanks/characters alongside the topic of pedophilia (lolicon/shotacon) and incest,
even if said topic is being portrayed negatively, or as "parody".

- Using my voicebanks/characters to promote hate speech, discrimination, or harmful organizations/ideologies/politics is prohibited.

- Do not violate UTAU's Usage Policy.
Do not pair my voicebanks with UTAUs that contradict these terms of use.



�\�\�t MODIFICATION �s�\�\


- Modifying configuration files such as oto.ini or generating .frq is allowed.
Permission is required to modify voice samples in any way.


�yDerivatives�z:�@Derivatives of any kind are prohibited.


�yAI usage�z:�@Permission is required to produce voicebanks. Inquire for more details.
- Use of voice data for any AI model that is unrelated to the original voicebank or its character is prohibited.



�\�\�t VOICEBANK ARTWORK �s�\�\


- When utilizing voicebank portraits, you must credit the artist. (Artist will be credited as the image file name)

- Using artwork to represent a different UTAU or character is prohibited.
Do not use characters for voice/face claims.

- Usage of artwork for AI training is prohibited.




----------------------------------------------



Official Website and Distribution:  
-
https://snowsorry-utau.carrd.co/



Support Contact:
-
snowsorry@outlook.com



Socials:
-
YOUTUBE:   https://www.youtube.com/@snowsorry-p
NICONICO:   https://www.nicovideo.jp/user/51782136
BILIBILI:   https://space.bilibili.com/3493131982998082

TWITTER:   https://twitter.com/snowsorry
BLUESKY:   https://bsky.app/profile/snowsorry.bsky.social

