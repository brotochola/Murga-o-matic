
�� ���̉���/�L�����N�^�[��R18�R���e���c�Ɏg�p���邱�Ƃ͋֎~����Ă��܂��B�@�y�[�W�����̗��p�K������ǂ݂��������B

�� Use of this voicebank/character in R18 content is prohibited. Please read the terms of use near the bottom of the page.


----------------------------------------------


Vincen-oto -Rubato-�@|�@���B���Z������ -Rubato-
         
       �y Japanese VCV �z 


----------------------------------------------



Voice Provider:�@Colle (snowsorry)

Author/Manager:�@snowsorry

Oto Configuration:�@Rev (rev_bmp)

�\

Recommended Resamplers:�@moresampler, WORLDLINE-R


----------------------------------------------


       �y PITCHES �z


Low �� High:  A2, D#3, G3, D4, G4, C#5, D5

�\


       �y END NOTES �z


Rest:�@�@[a R] 



----------------------------------------------


       �y VOICEBANK TERMS OF USE �z


FOR MORE DETAILS, READ HERE:
snowsorry-utau.carrd.co/#terms-of-use



�\�\�t CONTENT �s�\�\


�yR18 expression�z:�@FORBIDDEN.
- Content must comply with the "Application" guidelines.


�yViolent expression�z:�@Allowed.
- Do not use to depict or encourage real-life violence or crimes.


�yReligious expression�z:�@Allowed. 
- Do not use with the intent of proselytization nor as promotion for real-life actions.


�yFan art/Doujin�z:�@Allowed.
- Content must comply with the "Application" guidelines.


�yOriginal songs/works�z:�@Non-commercial use is allowed.
- Voicebank and author must be credited.


�yCommercial use�z:�@Permission required.
- Asset or data use for NFTs is prohibited.



�\�\�t APPLICATION �s�\�\


- Do not use my voicebanks/characters alongside the topic of pedophilia (lolicon/shotacon) and incest,
even if said topic is being portrayed negatively, or as "parody".

- Using my voicebanks/characters to promote hate speech, discrimination, or harmful organizations/ideologies/politics is prohibited.

- Do not violate UTAU's Usage Policy.
Do not pair my voicebanks with UTAUs that contradict these terms of use.



�\�\�t MODIFICATION �s�\�\


DISCLAIMER:�@Vocoflex was used to aid the creation of this voicebank with consent of the voice provider.
- Modifying configuration files such as oto.ini or generating .frq is allowed.


�yDerivatives�z:�@Derivatives of any kind are prohibited.


�yAI usage�z:�@Voicebank samples were processed by Vocoflex. 
- Using samples processed by Vocoflex for AI training is prohibited.



�\�\�t VOICEBANK ARTWORK �s�\�\


- When utilizing voicebank portraits, you must credit the artist. (Artist will be credited as the image file name)

- Using artwork to represent a different UTAU or character is prohibited.
Do not use characters for voice/face claims.

- Usage of artwork for AI training is prohibited.




----------------------------------------------



Official Website and Distribution:  
-
https://snowsorry-utau.carrd.co/



Support Contact:
-
snowsorry@outlook.com



Socials:
-
YOUTUBE:   https://www.youtube.com/@snowsorry-p
NICONICO:   https://www.nicovideo.jp/user/51782136
BILIBILI:   https://space.bilibili.com/3493131982998082

TWITTER:   https://twitter.com/snowsorry
BLUESKY:   https://bsky.app/profile/snowsorry.bsky.social

