Mike (�}�C�N)
_________________

Art: Galgani
Reclist: AkuP
oto.ini: AkuP
_________________ ESP

Gracias por descargar a Mike!!

notas: 
- El reclist no abarca todas las conexiones, asi que hay que ser creativo.

- Existe el dieresis en este reclist, y sirve para conectar vocales unidas a "i" y en algunos casos "u".
	Ej. "hay mas" [- a][aI m][ma][as R]

_________________ ENG

Thanks for downloading Mike!!

notes: 
- The reclist doesn't have the full connections, so you'll have to be creative.

- In this reclist exist he connection (as extra vowels) between vowel and weak vowel (in most of cases "i").
	Ex. "hay mas" [- a][aI m][ma][as R]

_________________

Si experimentas problemas por favor contactame:

SoundCloud: akup-1
YouTube: youtube.com/c/akup