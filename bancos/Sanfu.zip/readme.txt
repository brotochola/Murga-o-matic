Thank you for downloading this voicebank!
If you use the drawings in the "Extras" folder, please remember to credit the author! ^^
Icon by @mint_frappee

Italian CVVC (List by @MakkuPizza) ver 2.1

Voicebank information:
Pitches: C3, G3, C4, G3(Whisper)
Microphone: Blue Yeti
Suggested resamplers: tips, Moresampler

Extras: 
Inhales and exhales: br1, br2, br-out, -bre, bre
End exhales: x R
Vocal fries (C3 pitch only): - 'x, 'x, x', x'-