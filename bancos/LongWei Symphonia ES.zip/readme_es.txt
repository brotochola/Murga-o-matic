------------------------------------------------
    ¡Gracias por descargar "LW_Symphonia_es"!
------------------------------------------------


------------------------------------------------
     Descripción
------------------------------------------------
	Este banco de voces es un vocal masculino profundo. Se
	canta con estilos vocales adecuados para géneros
	como Clásico, Ópera y Orquestal,
	aunque también pretende ser lo suficientemente flexible
	para cubrir otros géneros.
------------------------------------------------
    INFORMACIÓN TÉCNICA
------------------------------------------------

Tonos
	[Ab2, D3, G3, C4, E4]
		
Rango Vocal Recomendado
	C2~C5

Idioma
	Español

Formato
	VCCV	nJokis

Motores recomendados
	doppeltler, fresamp, moresampler, f2resamp,
	EFB-GT

Géneros
	Clásico, Ópera, Orquestal, Réquiem,
	Gótico, Rock, Metal sinfónico

Configuraciones recomendadas
	(UTAU)
	P25
	(OpenUtau)
	Establezca el valor predeterminado de "Normalize" en "25"

------------------------------------------------
     Crédito
------------------------------------------------

Configuración y Voicer
	deadbyte

Arte
	maggoroach

------------------------------------------------
	Contacto
------------------------------------------------

Email
	deadd.byte@gmail.com

BlueSky
	@deadbyte.bsky.social

Twitter
	@dead_byt